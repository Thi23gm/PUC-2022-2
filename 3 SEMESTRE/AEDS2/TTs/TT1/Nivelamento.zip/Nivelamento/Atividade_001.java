import java.util.Scanner;
public class Atividade_001{
    public static boolean localisaNum(int num[], int resp){
        for(int i=0; i < num.length; i++ ){
            if (num[i] == resp)
            return true;
        }
        
        return false;
    }
    public static void main(String[] args) {
        int[] num;
        num = new int[50];
        int qunt, resp = 0;
        boolean resultado;
        Scanner myObj = new Scanner (System.in);
        System.out.println("Quantos numeros voce deseja incerir?");
        qunt = myObj.nextInt();
        for(int i = 1; i < qunt+1; i++){
            System.out.println("Digite o " + i + " numero:");
            num[i] = myObj.nextInt();
        }

        System.out.println("Digite o numero que deseja localizar: ");
        resp = myObj.nextInt();

        resultado = localisaNum(num, resp);
        if(resultado == true){
            System.out.println("\nNa Array digitada exixte o numero " + resp);
        }
        else{
            System.out.println("\nNa Array digitada nao existe o numero " + resp);
        }
    }
}
