import java.util.Scanner;
public class Atividade_002 {
    public static boolean function(int[] array, int num){
        for (int i = 0; i < array.length; i++){
            if (num > array[i])
            {
                return true;
            }
            else if(num < array[i])
            {
                return false;
            }
        }
        return false;
    } 
    
    public static void main(String[] args) {
        Scanner myObj = new Scanner (System.in);
        int[] array = new int[]{0, 2 , 3, 6, 7, 12, 13, 16, 18, 22, 25, 27, 41, 50};
        int num;
        boolean result;
        System.out.println("Digite o numero que deseja localizar: ");
        num = myObj.nextInt();
        result = function(array, num);
        if(result == true)
        {
            System.out.println("Na Array tem o numero " + num);
        }
        else
        {
            System.out.println("Na Array nao tem o numero " + num);
        }
    }
}
