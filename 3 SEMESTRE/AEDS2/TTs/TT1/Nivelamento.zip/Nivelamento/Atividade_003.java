import java.util.Scanner;
public class Atividade_003 {
    public static void main(String[] args) {
        Scanner myObj = new Scanner (System.in);
        int tam, maior, menor;
        System.out.println("Digite quantos numeros deseja inderir:");
        tam = myObj.nextInt();
        int[] array = new int[tam];
        for (int i = 0; i < tam; i++){
            System.out.println("Digite um Numero: ");
            array[i] = myObj.nextInt();
        }

        maior = array[0];
        menor = array[0];

        for(int i = 1; i < tam; i++){
            if(maior < array[i]){
                maior = array[i];
            }
        }
        for(int i = 1; i < tam; i++){
            if(menor > array[i]){
                menor = array[i];
            }
        }

        System.out.println("O maior numero da Array é o numero " + maior + " e o menor numero da Array é o numero " + menor);

    }
}
